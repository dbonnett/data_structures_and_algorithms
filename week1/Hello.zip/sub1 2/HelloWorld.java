import edu.princeton.cs.algs4.StdOut;

public class HelloWorld {
    public static void main(String[] args) {
        StdOut.println("Hello, World");
    }
}
